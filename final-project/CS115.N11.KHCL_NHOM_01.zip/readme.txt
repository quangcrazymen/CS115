Em đã bổ sung thêm phần giải thích sử dụng SVD trong việc nến một tấm ảnh, và
phần liên hệ giũa SVD và PCA. (file pdf để phòng nếu file pptx render ra sai format)
Về phần Demo thì em có bổ sung thêm 2 cái demo vè pca (do em chưa kịp trình bày):
Trong file PCA.ipynb là sử dụng PCA để có thể trực quan hóa bộ dữ liệu iris (bằng 2
cách tiếp cận là sử dụng SVD và eigenvalue decomposition).
Trong file principal_component_analysis.ipynb em sử dụng PCA để giảm chiều dữ liệu
trước khi thực hiện bài toán classification trên bộ dữ liệu wine.
+ Cập nhật lại thành viên là nhóm chỉ có 3 thành viên liệt kê trong slide. 
 
